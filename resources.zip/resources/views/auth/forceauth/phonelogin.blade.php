
<div class="modal fade" id="forcelogin" tabindex="-1" role="dialog" aria-labelledby="forcelogin" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="forcelogin">ورود / ثبت نام</h5>
        <button type="button" class="close" data-bs-dismiss="modal">
          <span aria-hidden="true">×</span>
          <span class="sr-only">نزدیک</span>
        </button>
      </div>
      <div class="modal-body">
        @include('auth.forceauth.loginform')
      </div>
    </div>
  </div>
</div>





